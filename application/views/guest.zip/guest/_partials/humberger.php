<div class="humberger__menu__overlay"></div>
<div class="humberger__menu__wrapper">
  <div class="humberger__menu__logo" style="width: 100px; height: 30px;">
    <a href="#"><img <img src="<?php echo base_url('assets/image/logo3.png') ?>" alt=""></a>
  </div>
  <nav class="humberger__menu__nav mobile-menu">
    <ul>
      <li class="active"><a href="./index.html">Home</a></li>
      <li><a href="./shop-grid.html">Shop</a></li>
      <li><a href="#">Pages</a>
        <ul class="header__menu__dropdown">
          <li><a href="./shop-details.html">Shop Details</a></li>
          <li><a href="./shoping-cart.html">Shoping Cart</a></li>
          <li><a href="./checkout.html">Check Out</a></li>
          <li><a href="./blog-details.html">Blog Details</a></li>
        </ul>
      </li>
      <li><a href="./blog.html">Blog</a></li>
      <li><a href="./contact.html">Contact</a></li>
    </ul>
  </nav>
  <div id="mobile-menu-wrap"></div>
  <div class="header__top__right__social">
    <a href="#"><i class="fa fa-facebook"></i></a>
    <a href="#"><i class="fa fa-twitter"></i></a>
    <a href="#"><i class="fa fa-linkedin"></i></a>
    <a href="#"><i class="fa fa-pinterest-p"></i></a>
  </div>
  <div class="humberger__menu__contact">
    <ul>
        <li><i class="fa fa-envelope"></i> @madiunkab.go.id</li>
        <li>Website Filtering kerja Sama UNS dengan Dinas Kesehatan</li>
    </ul>
  </div>
</div>