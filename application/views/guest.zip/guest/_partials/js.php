<!-- Plugin js for this page -->
<script src="<?php echo base_url('ogani/js/jquery-3.3.1.min.js') ?>"></script>
<script src="<?php echo base_url('ogani/js/bootstrap.min.js') ?>"></script>
<script src="<?php echo base_url('ogani/js/jquery.nice-select.min.js') ?>"></script>
<script src="<?php echo base_url('ogani/js/jquery-ui.min.js') ?>"></script>
<script src="<?php echo base_url('ogani/js/jquery.slicknav.js') ?>"></script>
<script src="<?php echo base_url('ogani/js/mixitup.min.js') ?>"></script>
<script src="<?php echo base_url('ogani/js/owl.carousel.min.js') ?>"></script>
<script src="<?php echo base_url('ogani/js/main.js') ?>"></script>
